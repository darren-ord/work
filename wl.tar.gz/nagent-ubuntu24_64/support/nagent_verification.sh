#!/bin/bash
executables=("/usr/sbin/nagent"
	"/opt/nable/usr/lib/libgloox.so.18"
	"/opt/nable/usr/lib/libgsoap.so"
	"/opt/nable/usr/lib/libmodule.so"
	"/opt/nable/usr/lib/libnable2.so"
	"/opt/nable/usr/lib/libsoapdata.so"
	"/opt/nable/usr/lib/libstdsoap2.so"
	"/opt/nable/usr/lib/libxmpp.so")
systemd_service_file=("/usr/lib/systemd/system/nagent.service")
nagent_pid_file=("/run/nagent.pid")
nagent_uninstall_script=("/home/nagent/uninstall.sh")
nagent_log_rotation_cron=("/etc/logrotate.d/nagent")
components_check()
{
	echo $1
	local -n filelist=$2``
	for file in "${filelist[@]}"; do
		if [ -f $file ]; then
			FILESIZE=$(stat -c%s "$file")
			echo "$file - found, file size $FILESIZE bytes"
		else
			echo "$file - not found"
		fi
	done
	echo ""
}
echo -e "### Linux Agent Components Check\n"
components_check "### nagent installable exacutables" executables
# mapfile -d '' module_array < <(find /home/nagent -maxdepth 1 -not -path '/home/nagent' -print0)
module_array=( $(ls /home/nagent/*.so) )
components_check "### nagent downloadable libraries" module_array 
config_array=( $(ls /home/nagent/*.conf) )
components_check "### nagent configuration" config_array
components_check "### nagent uninstallation script"  nagent_uninstall_script
components_check "### nagent service unit configuration file" systemd_service_file
components_check "### nagent pid file" nagent_pid_file
mapfile -d '' log_files_array < <(find /var/log/n-central -maxdepth 1 -not -path '/var/log/n-central' -print0)
log_files_array+=("/tmp/nagent-upgrade.log")
components_check "### nagent log files" log_files_array
components_check "### nagent log files rotation cron intruction" nagent_log_rotation_cron
