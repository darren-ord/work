#!/bin/bash
SOAP_POST_DATA="<?xml version=\"1.0\" encoding=\"UTF-8\"?> \
<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:SOAP-ENC=\"http://www.w3.org/2003/05/soap-encoding\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns1=\"http://mms3.nobj.nable.com/\"> \
<SOAP-ENV:Body><ns1:AgentInstallerCheckCustomer> \
<ns1:customerID>CID</ns1:customerID> \
<ns1:customerName>CNAME</ns1:customerName> \
</ns1:AgentInstallerCheckCustomer></SOAP-ENV:Body> \
</SOAP-ENV:Envelope>"
CURL_REQUEST="curl -i --header \"Content-Type: text/xml; charset=utf-8\" --header \"SOAPAction:\" --header \"User-Agent: gSoap\" --header \"Connection: Keep-Alive\" --header \"Host: FQDN\" --data '###' https://FQDN/dms2/services2/ServerMMS3"

printf 'This is MMS3 soap request of AgentInstallerCheckCustomer method using curl command\n'
echo "Returns \"Customer ID\" if valid \"Customer name\" and \"Customer ID\" were specified"
echo -e "Returns -1 if \"Customer name\" or \"Customer ID\" not valid\n"
echo "Enter N-central FQDN or IP (no protocol prefix): "
read SERVER
echo -en "Enter customer name (no quotes): "
read CNAME
echo -en "Enter customer ID (integer): "
read CID

SERVER=$(eval echo "$SERVER")
SOAP_POST_DATA="${SOAP_POST_DATA//CNAME/$CNAME}"
SOAP_POST_DATA="${SOAP_POST_DATA//CID/$CID}"
CURL_REQUEST="${CURL_REQUEST//FQDN/$SERVER}"
CURL_REQUEST="${CURL_REQUEST//###/$(echo "$SOAP_POST_DATA")}"
echo 
echo "Soap Data: $SOAP_POST_DATA"
printf '\ncurl soap request:\n\n'
echo "$CURL_REQUEST"
echo -e "\n$SERVER n-central response:\n"
eval "$CURL_REQUEST"
echo

