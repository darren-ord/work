#!/bin/bash
NAGENT_SERVICE=nagent.service

if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root. Re-run with sudo or as root."
    exit 1
fi
echo "Upgrade Linux agent"

select_os()
{
    echo "Select supported Linux OS"
    echo "   CentOS/RedHat 7 x64           - 1"
    echo "   CentOS/RedHat 8 x64           - 2"
    echo "   CentOS/RedHat/AlmaLinux 9 x64 - 3"
    echo "   Ubuntu 20/Debian 11 x64       - 4"
    echo "   Ubuntu 22/Debian 12 x64       - 5"
    echo "   Ubuntu 24/Debian 13 x64       - 6"
    while true; do
       echo -en "Pick an option: "
       read -r OS_OPTION
       if [[ ! "$OS_OPTION" =~ ^[0-6]$ ]]; then
           echo "$OS_OPTION is not correct option, please repeat or press 0 to exit"
       elif [[ "$OS_OPTION" == "0" ]]; then
           exit 2
       else
           break
       fi
    done
    
    case "$OS_OPTION" in
    1)
        OSID=rhel7_64
        ;;
    2)
        OSID=rhel8_64
        ;;
    3)
        OSID=rhel9_64
        ;;
    4)
        OSID=ubuntu20_64
        ;;
    5)
        OSID=ubuntu22_64
        ;;
    6)
        OSID=ubuntu24_64
	;;
    esac
}
# Check if nagent.service exists on this device
if ! systemctl list-unit-files --type=service | grep -q $NAGENT_SERVICE; then
    echo "Linux agent is not installed"
    exit 1
fi
select_os
INSTALLER="nagent-$OSID.tar.gz"
echo "Enter N-central FQDN or IP (no protocol prefix): "
read -r SERVER
echo -en "N-central version: "
read -r VERSION
INSTALLER_URL="https://$SERVER/download/$VERSION/$OSID/N-central/$INSTALLER"
echo $INSTALLER_URL
# Check installer URL
HTTP_RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" "$INSTALLER_URL")
if [ "$HTTP_RESPONSE" -ne 200 ]; then
    if [ "$HTTP_RESPONSE" -eq 000 ]; then
       echo "Could not resolve - $SERVER"
    else   
       echo "Response code for URL - $INSTALLER_URL is $HTTP_RESPONSE"
    fi
    exit 3
fi
echo "Download installer from $INSTALLER_URL"
curl --fail -O "$INSTALLER_URL"
retCode=$?
if [ $retCode -ne 0 ]; then
    echo "Download failed for $INSTALLER_URL, error code: $retCode"
    exit 4
fi
tar -zxvf "$INSTALLER"
retCode=$?
if [ $retCode -ne 0 ]; then
    echo "Extraction failed for $INSTALLER, error code: $retCode"
    exit 5
fi
echo "Start version management for $OSID."
systemctl stop nagent.service
case "$OS_OPTION" in
    1|2|3)
        NAGENTRPM=$(rpm -qa | grep nagent-rhel)
        rpm -e $NAGENTRPM
        retCode=$?
        if [ $retCode -ne 0 ]; then
           echo "rpm command failed on $OSID uninstall, error code: $retCode"
           exit 4
        fi
        rpm -Uvh nagent-rhel_64/nagent*.rpm 2>/dev/null
        retCode=$?
        if [ $retCode -ne 0 ]; then
            echo "rpm command failed on $OSID install, error code: $retCode"
            exit 5
        fi
        ;;
    *)
        dpkg -i nagent-$OSID/nagent.deb 2>/dev/null
        retCode=$?
        if [ $retCode -ne 0 ]; then
            echo "dpkg command failed on $OSID install, error code: $retCode"
            exit 6
        fi
        ;;
esac
systemctl start nagent.service


