#!/bin/bash
WS_URL_PATH="/commandprompt/?id=4e4e6b64-9caa-45d0-965a-df1a1930f3ff"

printf 'This script checks WebSocket availability on N-central using curl.\n'
echo "On success returns: \"HTTP/1.1 101 Switching Protocols \""

if [[ -t 0 ]]; then
    echo "Enter N-central FQDN or IP (no protocol prefix): "
    read -r SERVER
else
    SERVER="${1:?Usage: websocket_cmd_test.sh <fqdn-or-ip>}"
fi

[[ -z "$SERVER" ]] && { echo "Error: server address required." >&2; exit 1; }


if [[ ! "$SERVER" =~ ^[a-zA-Z0-9._-]+$ ]]; then
    echo "Error: invalid server address." >&2
    exit 1
fi

CURL_CMD=(curl -i --http1.1
  --header "Host: ${SERVER}"
  --header "Connection: Upgrade"
  --header "Upgrade: websocket"
  --header "Sec-WebSocket-Key: SGVsbG8sIHdvcmxkIQ=="
  --header "Sec-WebSocket-Version: 13"
  "https://${SERVER}:443${WS_URL_PATH}"
)

echo
printf '\nCurl WebSocket request:\n\n'
printf '%q ' "${CURL_CMD[@]}"
echo
printf '\n%s N-central response:\n\n' "$SERVER"
"${CURL_CMD[@]}" 2>&1 | grep -m1 '^HTTP/'
echo

